// ===============================
// LOGIN ZABBIX (login.js)
// ===============================

let zabbixAuthToken = null;

function login(event) {
    event.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const messageBox = document.getElementById("loginMessage");

    // Limpiar mensajes previos
    messageBox.textContent = "";
    messageBox.style.color = "";

    if (!username || !password) {
        messageBox.textContent = "⚠️ Por favor ingresa usuario y contraseña.";
        messageBox.style.color = "#ffcc00";
        return;
    }

    const zabbixUrl = "http://10.1.0.66/zabbix/api_jsonrpc.php";

    // === Estructura JSON-RPC exacta que quieres usar ===
    const loginData = {
        jsonrpc: "2.0",
        method: "user.login",
        params: {
            username: username,    // ✅ debe ser 'user', no 'username'
            password: password
        },
        id: 1
    };

    // Mostrar mensaje de carga
    messageBox.textContent = "⏳ Verificando credenciales...";
    messageBox.style.color = "#00ffff";

    fetch(zabbixUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.result) {
            // ✅ Login exitoso
            const token = data.result;
            sessionStorage.setItem("zabbixToken", token);
            sessionStorage.setItem("lastActivity", Date.now()); // Guardar hora de actividad

            messageBox.textContent = "✅ Login exitoso. Redirigiendo...";
            messageBox.style.color = "#00ff88";

            setTimeout(() => {
                window.location.href = "/HTML/index.html";
            }, 1000);
        } else {
            // ❌ Error de credenciales o estructura
            const msg = data.error?.data || "Usuario o contraseña incorrectos.";
            messageBox.textContent = "❌ " + msg;
            messageBox.style.color = "#f3f70eff";
            console.error("Error en login:", data);
        }
    })
    .catch(error => {
        console.error("❌ Error al conectar con Zabbix:", error);
        messageBox.textContent = "❌ No se pudo conectar con el servidor.";
        messageBox.style.color = "#ff5555";
    });
}
